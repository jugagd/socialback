## FaceClone HTML template

A very very basic Facebook clone template meant for readers of my Medium posts on building a Facebook clone with PHP from scratch. Download and build your own Facebook!

This template contains 3 main pages: **index.html**, **home.html** and **profile.html**. **template.html** is the layout file for FaceClone. You can use it to create other page templates.

FaceClone uses Bootstrap, a HTML, CSS and Javascript framework for making beautiful UIs quickly. You can check it out here: [https://getbootstrap.com](https://getbootstrap.com).