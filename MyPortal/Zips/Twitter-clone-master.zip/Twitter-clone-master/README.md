# Twitter-clone
This repository is a clone of a Twitter Page made with help of HTML5, CSS3 and Bootstrap as a part of front-end practice.
