# Linkedin Layout Clone

<p >
    <img src="/images/linkedin-layout-preview.png" > 
</p>

## Live Version

**[Click here! :)](http://linkedin-layout-clone.surge.sh/)**

## Project Overview

A clone of LinkedIn's Home Page using pure CSS. Responsive layout was created using Flexbox, Grid and Media Queries.
